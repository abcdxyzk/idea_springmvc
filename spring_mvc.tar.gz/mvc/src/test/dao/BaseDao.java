package test.dao;

import java.io.IOException;
import java.io.InputStream;

/**
 * 操作数据库的通用类
 * @author Think
 *
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class BaseDao {

    private static String driver;// 数据库驱动
    private static String url;// 数据库连接字符串
    private static String user;// 数据库用户名
    private static String password;

    static {
        init();
    }

    /**
     * 从配置文件中读取连接参数
     */
    public static void init() {
        Properties params = new Properties();
        String configfile = "database.properties";
        // 加载文件到输入流中
        InputStream is = BaseDao.class.getClassLoader().getResourceAsStream(configfile);
        // 从输入流中读取属性列表
        try {
            params.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 根据指定的键获得对应的值
        driver = params.getProperty("driver");
        url = params.getProperty("url");
        user = params.getProperty("user");
        password = params.getProperty("password");
    }

    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    // 1、打开数据库
    public Connection getConnection() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(url, user, password);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    // 2、关闭所有资源

    public void closeAll(Connection connection, PreparedStatement preparedStatement, ResultSet result) {
        if (result != null) {
            try {
                result.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // 3、增、删、改通用方法
    public int executeUpdate(String sql, Object[] param) {
        int num = 0;// 影响行数
        connection = this.getConnection();
        // PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(sql);
            // 为参数进行赋值
            if (param != null) {
                for (int i = 0; i < param.length; i++) {
                    preparedStatement.setObject(i + 1, param[i]);
                }
            }
            // 执行SQL语句
            num = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeAll(connection, preparedStatement, null);
        }
        return num;
    }

    /**
     * 执行查询操作 备注：此方法适用于纯查询使用，若是输入加查询需要另外设计
     *
     * @param sql 语句
     * @return
     */
    public ResultSet executeQuery(String sql) {

        connection = this.getConnection();
        // PreparedStatement preparedStatement = null;
        // ResultSet resultSet = null;
        try {
            // 发送SQL语句
            preparedStatement = connection.prepareStatement(sql);
            // 返回结果集
            resultSet = preparedStatement.executeQuery();
        } catch (Exception e) {

            closeAll(connection, preparedStatement, resultSet); // 关闭所有连接

            System.out.println("发生异常:\n" + e.getMessage());
        }
        return resultSet;
    }
}