package test.dao;

public class InfoDao {
}
