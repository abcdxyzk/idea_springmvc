package test;

import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import test.dao.BaseDao;

import java.sql.*;

@Controller
@RequestMapping("/mvc")
public class MyController {

    static BaseDao baseDB = new BaseDao();

    @RequestMapping("/hello")
    public String hello(Model model) {
        model.addAttribute("name","nameval");
        return "hello";
    }

    @RequestMapping("/db")
    public String db(Model model) {

        String ou = "";

        try {
            ResultSet rs  = baseDB.executeQuery("SELECT * FROM info;");
            while (rs.next()) {
                ou = ou + rs.getString("id") + "   &nbsp  " + rs.getString("name") + "  &nbsp " + rs.getInt("val"); //将查询结果输出
                ou = ou + "<br />";
            }
        } catch (Exception e) {
            return "err";
        }

        model.addAttribute("dv", ou);
        return "db";
    }
}

